#!/usr/bin/env bash
# clash-for-linux shell entry
export PATH="/usr/local/bin:$PATH"
export CLASH_FOR_LINUX_CLASH_ENTRY_MANAGED="false"

if [ -z "${CLASH_FOR_LINUX_SHELL_LOADED:-}" ] \
  && { [ -n "${BASH_VERSION:-}" ] || [ -n "${ZSH_VERSION:-}" ]; }; then
  # 文件作用域解析：zsh 函数内 $0 为函数名（FUNCTION_ARGZERO），不可封装成函数
  _clash_entry_self="${BASH_SOURCE[0]:-$0}"
  _clash_entry_dir="$(cd "$(dirname "$_clash_entry_self")" 2>/dev/null && pwd)" || _clash_entry_dir=""
  _clash_entry_project_dir=""
  if [ -n "${CLASH_FOR_LINUX_PROJECT_DIR:-}" ] \
    && [ -f "${CLASH_FOR_LINUX_PROJECT_DIR}/scripts/core/alias.sh" ]; then
    _clash_entry_project_dir="$CLASH_FOR_LINUX_PROJECT_DIR"
  elif [ -n "$_clash_entry_dir" ] && [ -f "$_clash_entry_dir/scripts/core/alias.sh" ]; then
    _clash_entry_project_dir="$_clash_entry_dir"
  elif [ -n "$_clash_entry_dir" ]; then
    _clash_entry_git_root="$(git -C "$_clash_entry_dir" rev-parse --show-toplevel 2>/dev/null || true)"
    if [ -n "$_clash_entry_git_root" ] && [ -f "$_clash_entry_git_root/scripts/core/alias.sh" ]; then
      _clash_entry_project_dir="$_clash_entry_git_root"
    fi
    unset _clash_entry_git_root
  fi
  if [ -n "$_clash_entry_project_dir" ]; then
    export CLASH_FOR_LINUX_PROJECT_DIR="$_clash_entry_project_dir"
    CLASH_FOR_LINUX_SHELL_LOADED="1"
    source "$_clash_entry_project_dir/scripts/core/alias.sh"
  fi
  unset _clash_entry_self _clash_entry_dir _clash_entry_project_dir
fi

case "$-" in
  *i*)
    if [ -n "${BASH_VERSION:-}" ] && [ -z "${CLASH_FOR_LINUX_BASH_COMPLETION_LOADED:-}" ]; then
      if [ -f "${CLASH_FOR_LINUX_PROJECT_DIR:-}/clash-for-linux-completion.bash" ]; then
        export CLASH_FOR_LINUX_BASH_COMPLETION_LOADED="1"
        source "${CLASH_FOR_LINUX_PROJECT_DIR}/clash-for-linux-completion.bash"
      elif [ -f "/etc/profile.d/clash-for-linux-completion.bash" ]; then
        export CLASH_FOR_LINUX_BASH_COMPLETION_LOADED="1"
        source "/etc/profile.d/clash-for-linux-completion.bash"
      fi
    elif [ -n "${ZSH_VERSION:-}" ] && [ -z "${CLASH_FOR_LINUX_ZSH_COMPLETION_LOADED:-}" ]; then
      if [ -f "${CLASH_FOR_LINUX_PROJECT_DIR:-}/clash-for-linux-completion.zsh" ]; then
        export CLASH_FOR_LINUX_ZSH_COMPLETION_LOADED="1"
        source "${CLASH_FOR_LINUX_PROJECT_DIR}/clash-for-linux-completion.zsh"
      elif [ -f "/etc/profile.d/clash-for-linux-completion.zsh" ]; then
        export CLASH_FOR_LINUX_ZSH_COMPLETION_LOADED="1"
        source "/etc/profile.d/clash-for-linux-completion.zsh"
      fi
    fi
    ;;
esac
