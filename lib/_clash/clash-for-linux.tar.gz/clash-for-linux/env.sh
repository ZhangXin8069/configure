#!/usr/bin/env bash
# clash-for-linux one-shot proxy environment
# 用法：在任意目录/任意用户 Shell 中执行
#   source /path/to/clash-for-linux/env.sh
# 行为：仅向当前 Shell export 代理变量（一次性），不注册别名/函数/补全，不写任何持久化文件。

# 项目路径解析契约与 clash-for-linux.sh 一致：
# CLASH_FOR_LINUX_PROJECT_DIR → 本文件所在目录 → git rev-parse --show-toplevel
_clash_env_dir="$(cd "$(dirname "${BASH_SOURCE[0]:-$0}")" 2>/dev/null && pwd)" || _clash_env_dir=""
_clash_env_project="${CLASH_FOR_LINUX_PROJECT_DIR:-}"
if [ -n "$_clash_env_project" ] && [ -f "$_clash_env_project/scripts/core/alias.sh" ]; then
  :
elif [ -n "$_clash_env_dir" ] && [ -f "$_clash_env_dir/scripts/core/alias.sh" ]; then
  _clash_env_project="$_clash_env_dir"
else
  _clash_env_git="$(git -C "$_clash_env_dir" rev-parse --show-toplevel 2>/dev/null || true)"
  if [ -n "$_clash_env_git" ] && [ -f "$_clash_env_git/scripts/core/alias.sh" ]; then
    _clash_env_project="$_clash_env_git"
  fi
fi

if [ -z "$_clash_env_project" ]; then
  echo "clash-for-linux env.sh: 无法定位项目目录（请在仓库内 source，或先 export CLASH_FOR_LINUX_PROJECT_DIR）" >&2
else
  export CLASH_FOR_LINUX_PROJECT_DIR="$_clash_env_project"

  # 端口解析链：runtime/config.yaml(yq→sed) → runtime/install.env INSTALL_PLAN_MIXED_PORT → 7890
  _clash_env_port=""
  _clash_env_cfg="$_clash_env_project/runtime/config.yaml"
  if [ -s "$_clash_env_cfg" ]; then
    _clash_env_yq="$_clash_env_project/runtime/bin/yq"
    if [ -x "$_clash_env_yq" ]; then
      _clash_env_port="$("$_clash_env_yq" eval '.["mixed-port"] // .port // ""' "$_clash_env_cfg" 2>/dev/null | head -n 1)"
      [ -n "$_clash_env_port" ] && [ "$_clash_env_port" != "null" ] || _clash_env_port=""
    fi
    if [ -z "$_clash_env_port" ]; then
      _clash_env_port="$(sed -nE 's/^[[:space:]]*(mixed-port|port):[[:space:]]*"?([0-9]+)"?[[:space:]]*$/\2/p' "$_clash_env_cfg" 2>/dev/null | head -n 1)"
    fi
  fi
  if [ -z "$_clash_env_port" ]; then
    _clash_env_port="$(sed -nE 's/^INSTALL_PLAN_MIXED_PORT="?([0-9]+)"?$/\1/p' "$_clash_env_project/runtime/install.env" 2>/dev/null | head -n 1)"
  fi
  case "$_clash_env_port" in
    ""|*[!0-9]*) _clash_env_port=7890 ;;
  esac

  # 导出语义与 scripts/core/alias.sh: _clash_alias_export_proxy_values 逐字一致
  _clash_env_host="${CLASH_PROXY_HOST:-127.0.0.1}"
  export http_proxy="http://${_clash_env_host}:${_clash_env_port}"
  export HTTP_PROXY="$http_proxy"
  export https_proxy="$http_proxy"
  export HTTPS_PROXY="$https_proxy"
  export all_proxy="socks5://${_clash_env_host}:${_clash_env_port}"
  export ALL_PROXY="$all_proxy"
  export no_proxy="${NO_PROXY_DEFAULT:-127.0.0.1,localhost,::1}"
  export NO_PROXY="$no_proxy"
fi

# ── 代理显示与连通性检测（source 后可用） ──────────────────────────
# 设计目标：轻量、无外部依赖（仅 curl/wget 可选），兼容 bash/zsh，不污染 caller 的 $@
# 提供三个对外函数：clash_env_proxy_show / clash_env_proxy_test / clash_env_proxy_status
#   clash_env_proxy_show  — 显示当前 8 个代理变量 + 项目目录 + 端口解析来源
#   clash_env_proxy_test  — 检验代理是否可用（curl -x 走代理访问测试 URL）
#   clash_env_proxy_status — show + test 组合，一键展示与检验
# 可选自动触发：source env.sh --show|--test|--status 或设置 CLASH_ENV_AUTO_SHOW=true
#   默认保持静默（兼容 AGENTS.md“成功静默”约定），仅在显式请求时输出。

# 显示当前代理环境（只读，不改状态）
clash_env_proxy_show() {
  local _show_project="${CLASH_FOR_LINUX_PROJECT_DIR:-<未设置>}"
  local _show_http="${http_proxy:-${HTTP_PROXY:-<未设置>}}"
  local _show_https="${https_proxy:-${HTTPS_PROXY:-<未设置>}}"
  local _show_all="${all_proxy:-${ALL_PROXY:-<未设置>}}"
  local _show_no="${no_proxy:-${NO_PROXY:-<未设置>}}"
  local _show_cfg_port="" _show_install_port="" _show_effective_port=""
  local _show_host="${CLASH_PROXY_HOST:-127.0.0.1}"

  # 尝试回溯端口来源（与上方解析链一致，仅用于展示）
  if [ -n "${_show_project}" ] && [ "${_show_project}" != "<未设置>" ]; then
    if [ -s "${_show_project}/runtime/config.yaml" ]; then
      if [ -x "${_show_project}/runtime/bin/yq" ]; then
        _show_cfg_port="$("${_show_project}/runtime/bin/yq" eval '.["mixed-port"] // .port // ""' "${_show_project}/runtime/config.yaml" 2>/dev/null | head -n 1)"
        [ "${_show_cfg_port}" = "null" ] && _show_cfg_port=""
      fi
      [ -z "${_show_cfg_port}" ] && _show_cfg_port="$(sed -nE 's/^[[:space:]]*(mixed-port|port):[[:space:]]*"?([0-9]+)"?[[:space:]]*$/\2/p' "${_show_project}/runtime/config.yaml" 2>/dev/null | head -n 1)"
    fi
    _show_install_port="$(sed -nE 's/^INSTALL_PLAN_MIXED_PORT="?([0-9]+)"?$/\1/p' "${_show_project}/runtime/install.env" 2>/dev/null | head -n 1)"
  fi
  # 从已 export 的变量推导有效端口
  _show_effective_port="$(printf '%s' "${_show_http}" | sed -nE 's|.*:([0-9]+).*|\1|p' | head -n 1)"
  [ -z "${_show_effective_port}" ] && _show_effective_port="<未知>"

  echo ""
  echo "🐱 当前代理环境 (env.sh)"
  echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
  echo "📂 项目目录 : ${_show_project}"
  echo "🌐 http_proxy  : ${_show_http}"
  echo "🔒 https_proxy : ${_show_https}"
  echo "🧦 all_proxy   : ${_show_all}"
  echo "🚫 no_proxy    : ${_show_no}"
  echo "🔌 生效端口    : ${_show_effective_port} (host=${_show_host})"
  if [ -n "${_show_cfg_port}" ]; then
    echo "📄 配置端口    : ${_show_cfg_port} (runtime/config.yaml)"
  fi
  if [ -n "${_show_install_port}" ]; then
    echo "📦 安装规划端口: ${_show_install_port} (runtime/install.env)"
  fi
  # 运行时状态（若可探测）
  if [ -n "${_show_project}" ] && [ "${_show_project}" != "<未设置>" ] && [ -f "${_show_project}/runtime/mihomo.pid" ]; then
    local _pid
    _pid="$(cat "${_show_project}/runtime/mihomo.pid" 2>/dev/null || true)"
    if [ -n "${_pid}" ] && kill -0 "${_pid}" 2>/dev/null; then
      echo "🐱 内核状态    : 运行中 (pid=${_pid})"
    else
      echo "❗ 内核状态    : pid 文件存在但进程不在运行"
    fi
  fi
  echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
  echo ""
}

# 检验代理是否可用
# 用法: clash_env_proxy_test [测试URL] [超时秒]
# 默认 URL: https://www.gstatic.com/generate_204（轻量 204）
# 返回码: 0 成功，1 代理不可用，2 环境缺失/跳过
clash_env_proxy_test() {
  local _test_url="${1:-https://www.gstatic.com/generate_204}"
  local _test_timeout="${2:-${CLASH_ENV_TEST_TIMEOUT:-5}}"
  local _proxy="${http_proxy:-${HTTP_PROXY:-}}"
  local _rc=0

  # 允许通过环境变量覆盖 URL
  if [ -n "${CLASH_ENV_TEST_URL:-}" ] && [ "$_test_url" = "https://www.gstatic.com/generate_204" ]; then
    _test_url="$CLASH_ENV_TEST_URL"
  fi

  echo "🔍 代理连通性检测"
  echo "   代理 : ${_proxy:-<未设置>}"
  echo "   目标 : ${_test_url}"
  echo "   超时 : ${_test_timeout}s"

  if [ -z "${_proxy}" ]; then
    echo "❌ 未设置 http_proxy/HTTP_PROXY，无法检测" >&2
    return 2
  fi

  # 提取 host:port 做本地端口可达性预检（不依赖外网）
  local _proxy_hostport
  _proxy_hostport="$(printf '%s' "${_proxy}" | sed -nE 's|^[a-z]+://([^/]+).*|\1|p')"
  if [ -n "${_proxy_hostport}" ]; then
    local _phost="${_proxy_hostport%%:*}"
    local _pport="${_proxy_hostport##*:}"
    # 简单 TCP 探测（bash /dev/tcp，超时 2s）
    if command -v timeout >/dev/null 2>&1; then
      if timeout 2 bash -c "cat < /dev/null > /dev/tcp/${_phost}/${_pport}" 2>/dev/null; then
        echo "   端口 : ${_phost}:${_pport} 可达"
      else
        echo "   端口 : ${_phost}:${_pport} 不可达（代理可能未启动）" >&2
      fi
    fi
  fi

  if command -v curl >/dev/null 2>&1; then
    echo "   工具 : curl"
    # -x 显式走代理，-fsSL 静默失败，-o /dev/null 丢弃 body，-w 输出 http_code，可用于 204 校验
    local _http_code
    _http_code="$(curl -x "${_proxy}" -fsSL --max-time "${_test_timeout}" -o /dev/null -w "%{http_code}" "${_test_url}" 2>&1)" || _rc=$?
    if [ "${_rc}" -eq 0 ]; then
      # generate_204 正常返回 204，其他 URL 只要 2xx/3xx 都算通
      case "${_http_code}" in
        204|200|301|302|307|308)
          echo "✅ 代理可用 (HTTP ${_http_code})"
          return 0
          ;;
        *)
          # 即使 http_code 非预期，只要 curl 成功也视为代理通路 OK（目标可能返回 4xx）
          if [ -n "${_http_code}" ] && [ "${_http_code}" != "000" ]; then
            echo "✅ 代理通路可用 (HTTP ${_http_code}，目标可达)"
            return 0
          fi
          echo "⚠️ 代理返回异常 HTTP ${_http_code}" >&2
          return 1
          ;;
      esac
    else
      echo "❌ 代理不可用 (curl 退出码 ${_rc})" >&2
      # 额外诊断：尝试直连（不走代理）对比
      if curl --noproxy "*" -fsSL --max-time 3 -o /dev/null "${_test_url}" 2>/dev/null; then
        echo "   诊断 : 直连可达，说明代理链路问题" >&2
      else
        echo "   诊断 : 直连亦不可达，可能是网络或目标不可达" >&2
      fi
      return 1
    fi
  elif command -v wget >/dev/null 2>&1; then
    echo "   工具 : wget"
    if wget -e use_proxy=yes -e "http_proxy=${_proxy}" -e "https_proxy=${_proxy}" --timeout="${_test_timeout}" --tries=1 -q -O /dev/null "${_test_url}" 2>&1; then
      echo "✅ 代理可用 (wget)"
      return 0
    else
      _rc=$?
      echo "❌ 代理不可用 (wget 退出码 ${_rc})" >&2
      return 1
    fi
  else
    echo "⚠️ 未找到 curl/wget，跳过外网连通性检测" >&2
    echo "   提示 : 仅完成本地变量与端口可达性检查" >&2
    # 无外网工具时，端口可达即视为半成功
    if [ -n "${_proxy_hostport}" ] && command -v timeout >/dev/null 2>&1 && timeout 2 bash -c "cat < /dev/null > /dev/tcp/${_phost}/${_pport}" 2>/dev/null; then
      echo "✅ 本地代理端口可达（外网未校验）"
      return 0
    fi
    return 2
  fi
}

# 组合：显示 + 检验
clash_env_proxy_status() {
  clash_env_proxy_show
  clash_env_proxy_test "$@"
}

# 兼容别名（便于记忆）
clash_proxy_show() { clash_env_proxy_show "$@"; }
clash_proxy_test() { clash_env_proxy_test "$@"; }
clash_proxy_status() { clash_env_proxy_status "$@"; }

# ── 可选自动触发（保持默认静默） ────────────────────────────────
# 触发条件（任一满足即自动执行）：
#   1. source env.sh --show / --test / --status / --check
#   2. 环境变量 CLASH_ENV_AUTO_SHOW=true 或 CLASH_ENV_AUTO_CHECK=true
# 为避免污染 caller 的位置参数，保存后恢复。
{
  _clash_env_auto_args="$*"
  # 若是通过 source 传入的参数，则 $1 等会保留；直接执行时 $* 为空
  _clash_env_auto_trigger=""
  case "${_clash_env_auto_args}" in
    *--show*|*--status*|*--check*) _clash_env_auto_trigger="show" ;;
  esac
  case "${_clash_env_auto_args}" in
    *--test*|*--check*|*--status*) _clash_env_auto_trigger="${_clash_env_auto_trigger}:test" ;;
  esac
  if [ "${CLASH_ENV_AUTO_SHOW:-}" = "true" ] || [ "${CLASH_ENV_AUTO_CHECK:-}" = "true" ]; then
    _clash_env_auto_trigger="show:test"
  fi
  # 帮助
  case "${_clash_env_auto_args}" in
    *--help*|*-h*)
      echo "用法: source /path/to/env.sh [--show|--test|--status|--check|--help]"
      echo "  --show    仅显示当前代理"
      echo "  --test    仅检验代理连通性"
      echo "  --status  显示并检验（等价 --check）"
      echo "  --help    显示此帮助"
      echo "环境变量:"
      echo "  CLASH_ENV_AUTO_SHOW=true  source 时自动显示"
      echo "  CLASH_ENV_TEST_URL / CLASH_ENV_TEST_TIMEOUT  覆盖测试目标与超时"
      _clash_env_auto_trigger=""
      ;;
  esac

  if [ -n "${_clash_env_auto_trigger}" ] && [ -n "${_clash_env_project:-}" ]; then
    case "${_clash_env_auto_trigger}" in
      show) clash_env_proxy_show ;;
      :test) clash_env_proxy_test ;;
      show:test|test:show) clash_env_proxy_status ;;
      *:test) clash_env_proxy_test ;;
      show:*) clash_env_proxy_show ;;
    esac
  elif [ -n "${_clash_env_auto_trigger}" ] && [ -z "${_clash_env_project:-}" ]; then
    # 项目未定位时仍尝试显示变量（便于调试）
    case "${_clash_env_auto_trigger}" in
      *show*) clash_env_proxy_show ;;
      *test*) clash_env_proxy_test ;;
    esac
  fi
  unset _clash_env_auto_args _clash_env_auto_trigger
}

unset _clash_env_dir _clash_env_project _clash_env_git _clash_env_cfg _clash_env_yq _clash_env_port _clash_env_host
