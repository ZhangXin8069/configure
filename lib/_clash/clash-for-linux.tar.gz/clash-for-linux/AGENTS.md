# AGENTS.md — clash-for-linux（本目录）

上游 clash-for-linux 的本地工作副本。核心约定如下，供后续 agent 会话遵循。

## 路径动态化契约（跨目录/跨用户/跨设备）

- 项目路径解析顺序：`CLASH_FOR_LINUX_PROJECT_DIR` 环境变量 → `BASH_SOURCE[0]:-$0` 所在目录含 `scripts/core/alias.sh` → `git -C <目录> rev-parse --show-toplevel`（参考 `/root/configure/bin/gpull.sh`）。
- **禁止**在活跃代码中硬编码 `/root/clash-for-linux`；`/etc/profile.d` 仅允许出现在两处：legacy 清理逻辑与入口脚本的补全 fallback。
- zsh 注意：函数内 `$0` 是函数名（FUNCTION_ARGZERO 默认开启），自解析必须写在**文件作用域**，不可封装成函数。
- 根目录 `clash-for-linux.sh` 为规范入口模板；`install_shell_alias_entry`（common.sh）生成的入口与其 heredoc 体逐字一致（改一处必同步另一处，可用 diff 校验）。
- 补全由 `scripts/core/completion.sh: completion_emit_script_body` 生成，仓库根两个 checked-in 文件是产物：改动生成器后须重跑
  `bash scripts/core/clashctl.sh completion bash > clash-for-linux-completion.bash`（zsh 同理）。
- 根目录 `env.sh`：一次性代理环境入口——任意目录/用户 `source env.sh` 仅 export 8 个代理变量（语义同 alias.sh），
  端口链 `runtime/config.yaml(yq→sed) → runtime/install.env → 7890`；不注册别名/函数，成功静默。

## 默认行为约定

| .env 键 | 默认 | 说明 |
|---|---|---|
| `CLASH_DEFAULT_PROXY_NODE` | `美国圣何塞` | clashon 时对 DIRECT 类或未定制（当前=首候选）的手动策略组优先选中该节点；显式置空禁用 |
| `CLASH_SUB_UPDATE_INTERVAL_MINUTES` | `1440` | 开代理时超过该间隔自动刷新订阅（marker：`runtime/.sub-last-update`）；0 关闭；失败软处理不阻塞 |

## 验证命令

```bash
bash -n clash-for-linux.sh scripts/core/{common,proxy,clashctl,completion}.sh   # 语法
bash scripts/dev/check-home-unset-install-paths.sh                              # HOME 未设路径解析
bash scripts/dev/check-zsh-completion-safe.sh                                   # zsh 补全无副作用
```

## 其他

- `runtime/` 下资产（geoip.metadb 等）被上游跟踪但本地常有漂移，判断改动归属先看 mtime。
- `.agent.*.list/.log`、`.all.*.log` 不入库。
