import{aP as e,aQ as a}from"./index-DkxojdXb.js";const s=async()=>{e.value=[],a.value=[]};export{s as fetchRules};
